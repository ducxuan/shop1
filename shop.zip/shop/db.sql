-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th9 20, 2018 lúc 10:24 AM
-- Phiên bản máy phục vụ: 10.1.28-MariaDB
-- Phiên bản PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bills`
--

CREATE TABLE `bills` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_customer` int(11) DEFAULT NULL,
  `date_order` date DEFAULT NULL,
  `total` float DEFAULT NULL COMMENT 'tổng tiền',
  `payment` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'hình thức thanh toán',
  `note` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `bills`
--

INSERT INTO `bills` (`id`, `id_customer`, `date_order`, `total`, `payment`, `note`, `created_at`, `updated_at`) VALUES
(14, 14, '2017-03-23', 160000, 'COD', 'k', '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(13, 13, '2017-03-21', 400000, 'ATM', 'Vui lòng giao hàng trước 5h', '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(12, 12, '2017-03-21', 520000, 'COD', 'Vui lòng chuyển đúng hạn', '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(11, 11, '2017-03-21', 420000, 'COD', 'không chú', '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(15, 15, '2017-03-24', 220000, 'COD', 'e', '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(16, 17, '2018-06-13', NULL, 'ATM', 'ok', '2018-06-13 11:57:30', '2018-06-13 11:57:30'),
(17, 18, '2018-06-13', NULL, 'ATM', 'ok', '2018-06-13 11:58:28', '2018-06-13 11:58:28'),
(18, 19, '2018-06-13', NULL, 'COD', 'hjbvjad', '2018-06-13 13:05:45', '2018-06-13 13:05:45'),
(19, 20, '2018-06-13', NULL, 'COD', 'hjbvjad', '2018-06-13 13:07:10', '2018-06-13 13:07:10'),
(20, 21, '2018-06-14', 11, 'COD', 'ok babe', '2018-06-14 04:14:20', '2018-06-14 04:14:20'),
(21, 22, '2018-06-14', 11, 'COD', 'ạdfjadkfbka', '2018-06-14 04:21:29', '2018-06-14 04:21:29'),
(22, 23, '2018-06-14', NULL, 'COD', 'ạdfjadkfbka', '2018-06-14 04:30:30', '2018-06-14 04:30:30'),
(23, 24, '2018-06-14', NULL, 'COD', 'ạdfjadkfbka', '2018-06-14 04:31:21', '2018-06-14 04:31:21'),
(24, 25, '2018-06-14', 11, 'COD', 'khsgbwjks', '2018-06-14 04:31:57', '2018-06-14 04:31:57'),
(25, 26, '2018-06-14', 11, 'COD', 'qẹhefjeh', '2018-06-14 05:02:23', '2018-06-14 05:02:23'),
(26, 27, '2018-06-14', 11, 'COD', 'hdbvjsk', '2018-06-14 05:03:33', '2018-06-14 05:03:33'),
(27, 28, '2018-06-14', 11, 'COD', 'ADJBVJDKSV', '2018-06-14 05:05:54', '2018-06-14 05:05:54'),
(28, 29, '2018-06-14', 11, 'COD', 'hdsgvs', '2018-06-14 05:07:05', '2018-06-14 05:07:05'),
(29, 30, '2018-06-14', 11, 'COD', 'fewjghwjgh', '2018-06-14 05:08:33', '2018-06-14 05:08:33'),
(30, 31, '2018-06-14', 11, 'COD', 'fwhedfhwjf', '2018-06-14 05:10:11', '2018-06-14 05:10:11'),
(31, 32, '2018-06-14', 11, 'COD', 'fshghs', '2018-06-14 05:13:33', '2018-06-14 05:13:33'),
(32, 33, '2018-06-14', 11, 'COD', 'tfydfys', '2018-06-14 05:15:42', '2018-06-14 05:15:42'),
(33, 34, '2018-06-14', 11, 'COD', 'fjwhrgw', '2018-06-14 05:16:31', '2018-06-14 05:16:31'),
(34, 35, '2018-06-14', 11, 'COD', 'hdfgjsdh', '2018-06-14 05:17:40', '2018-06-14 05:17:40'),
(35, 36, '2018-06-14', 11, 'COD', 'dfhgsh', '2018-06-14 05:19:05', '2018-06-14 05:19:05'),
(36, 37, '2018-06-14', 11, 'COD', 'ùygsda', '2018-06-14 05:20:29', '2018-06-14 05:20:29'),
(37, 38, '2018-06-14', 11, 'COD', 'sgivjdgh', '2018-06-14 05:21:31', '2018-06-14 05:21:31'),
(38, 39, '2018-06-18', 70, 'COD', 'fghfhfhf', '2018-06-18 08:24:17', '2018-06-18 08:24:17'),
(39, 40, '2018-06-18', 14, 'COD', 'nhanh nha', '2018-06-18 09:45:48', '2018-06-18 09:45:48'),
(40, 41, '2018-06-19', 55, 'COD', 'giao nhanh nhá', '2018-06-19 01:37:43', '2018-06-19 01:37:43'),
(41, 42, '2018-09-13', 15, 'COD', 'adgfda', '2018-09-13 02:23:16', '2018-09-13 02:23:16');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill_detail`
--

CREATE TABLE `bill_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bill` int(10) NOT NULL,
  `id_product` int(10) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'số lượng',
  `unit_price` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `bill_detail`
--

INSERT INTO `bill_detail` (`id`, `id_bill`, `id_product`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES
(18, 15, 62, 5, 220000, '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(17, 14, 2, 1, 160000, '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(16, 13, 60, 1, 200000, '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(15, 13, 59, 1, 200000, '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(14, 12, 60, 2, 200000, '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(13, 12, 61, 1, 120000, '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(12, 11, 61, 1, 120000, '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(11, 11, 57, 2, 150000, '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(19, 24, 1, 1, 11, '2018-06-14 04:31:57', '2018-06-14 04:31:57'),
(20, 25, 1, 1, 11, '2018-06-14 05:02:23', '2018-06-14 05:02:23'),
(21, 26, 1, 1, 11, '2018-06-14 05:03:33', '2018-06-14 05:03:33'),
(22, 27, 1, 1, 11, '2018-06-14 05:05:54', '2018-06-14 05:05:54'),
(23, 28, 1, 1, 11, '2018-06-14 05:07:05', '2018-06-14 05:07:05'),
(24, 29, 1, 1, 11, '2018-06-14 05:08:33', '2018-06-14 05:08:33'),
(25, 30, 1, 1, 11, '2018-06-14 05:10:11', '2018-06-14 05:10:11'),
(26, 31, 1, 1, 11, '2018-06-14 05:13:33', '2018-06-14 05:13:33'),
(27, 32, 1, 1, 11, '2018-06-14 05:15:42', '2018-06-14 05:15:42'),
(28, 33, 1, 1, 11, '2018-06-14 05:16:31', '2018-06-14 05:16:31'),
(29, 34, 1, 1, 11, '2018-06-14 05:17:40', '2018-06-14 05:17:40'),
(30, 35, 1, 1, 11, '2018-06-14 05:19:05', '2018-06-14 05:19:05'),
(31, 36, 1, 1, 11, '2018-06-14 05:20:29', '2018-06-14 05:20:29'),
(32, 37, 1, 1, 11, '2018-06-14 05:21:31', '2018-06-14 05:21:31'),
(33, 38, 7, 10, 7, '2018-06-18 08:24:17', '2018-06-18 08:24:17'),
(34, 39, 2, 7, 2, '2018-06-18 09:45:48', '2018-06-18 09:45:48'),
(35, 40, 1, 5, 11, '2018-06-19 01:37:43', '2018-06-19 01:37:43'),
(36, 41, 3, 5, 3, '2018-09-13 02:23:17', '2018-09-13 02:23:17');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`id`, `name`, `gender`, `email`, `address`, `phone_number`, `note`, `created_at`, `updated_at`) VALUES
(15, 'ê', 'Nữ', 'huongnguyen@gmail.com', 'e', 'e', 'e', '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(14, 'hhh', 'nam', 'huongnguyen@gmail.com', 'Lê thị riêng', '99999999999999999', 'k', '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(13, 'Hương Hương', 'Nữ', 'huongnguyenak96@gmail.com', 'Lê Thị Riêng, Quận 1', '23456789', 'Vui lòng giao hàng trước 5h', '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(12, 'Khoa phạm', 'Nam', 'khoapham@gmail.com', 'Lê thị riêng', '1234567890', 'Vui lòng chuyển đúng hạn', '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(11, 'Hương Hương', 'Nữ', 'huongnguyenak96@gmail.com', 'Lê Thị Riêng, Quận 1', '234567890-', 'không chú', '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(16, 'nguyen van duc', 'nam', 'nguyenducbkk61@gmail.com', 'phủ doãn', '01668948823', 'giao nhanh', '2018-06-13 00:37:25', '2018-06-13 00:37:25'),
(17, 'nguyễn văn đức', 'nam', 'nguyenducbkk61@gmail.com', 'phủ doãn', '01668948823', 'ok', '2018-06-13 11:57:30', '2018-06-13 11:57:30'),
(18, 'nguyễn văn đức', 'nam', 'nguyenducbkk61@gmail.com', 'phủ doãn', '01668948823', 'ok', '2018-06-13 11:58:28', '2018-06-13 11:58:28'),
(19, 'sdhbs', 'nam', 'nguyenducbkk61@gmail.com', 'sdmnvbs', 'jsbd', 'hjbvjad', '2018-06-13 13:05:45', '2018-06-13 13:05:45'),
(20, 'sdhbs', 'nam', 'nguyenducbkk61@gmail.com', 'sdmnvbs', 'jsbd', 'hjbvjad', '2018-06-13 13:07:10', '2018-06-13 13:07:10'),
(21, 'đức', 'nam', 'nguyenducbkk61@gmail.com', 'anh yêu em', '01668945566', 'ok babe', '2018-06-14 04:14:20', '2018-06-14 04:14:20'),
(22, 'nhudgjs', 'nam', 'nguyenducbkk61@gmail.com', 'ahfjahfjka', 'ahdfjkadf', 'ạdfjadkfbka', '2018-06-14 04:21:29', '2018-06-14 04:21:29'),
(23, 'nhudgjs', 'nam', 'nguyenducbkk61@gmail.com', 'ahfjahfjka', 'ahdfjkadf', 'ạdfjadkfbka', '2018-06-14 04:30:30', '2018-06-14 04:30:30'),
(24, 'nhudgjs', 'nam', 'nguyenducbkk61@gmail.com', 'ahfjahfjka', 'ahdfjkadf', 'ạdfjadkfbka', '2018-06-14 04:31:21', '2018-06-14 04:31:21'),
(25, 'kwgjs', 'nam', 'nguyenducbkk61@gmail.com', 'shjfwkjs', 'dshgftbw', 'khsgbwjks', '2018-06-14 04:31:57', '2018-06-14 04:31:57'),
(26, 'jdfewjf', 'nam', 'nguyenducbkk61@gmail.com', 'dqhefhe', 'qhdjfh', 'qẹhefjeh', '2018-06-14 05:02:23', '2018-06-14 05:02:23'),
(27, 'scjshc', 'nam', 'nguyenducbkk61@gmail.com', 'sahfcjdav', 'cvhjdhc', 'hdbvjsk', '2018-06-14 05:03:33', '2018-06-14 05:03:33'),
(28, 'AHDVBA', 'nam', 'nguyenducbkk61@gmail.com', 'SJVBSDJH', 'UYWFEIUF', 'ADJBVJDKSV', '2018-06-14 05:05:54', '2018-06-14 05:05:54'),
(29, 'advhbskjdg', 'nam', 'nguyenducbkk61@gmail.com', 'sdbvgsjkv', 'hsvgbjdv', 'hdsgvs', '2018-06-14 05:07:05', '2018-06-14 05:07:05'),
(30, 'hdgrkj', 'nam', 'nguyenducbkk61@gmail.com', 'dsvfksjgv', 'ưefwbjf', 'fewjghwjgh', '2018-06-14 05:08:33', '2018-06-14 05:08:33'),
(31, 'hdvjdwfc', 'nam', 'nguyenducbkk61@gmail.com', 'dhfcjwhfcjw', 'ưdehfcwef', 'fwhedfhwjf', '2018-06-14 05:10:11', '2018-06-14 05:10:11'),
(32, 'sfgh', 'nam', 'nguyenducbkk61@gmail.com', 'hfsgvsh', 'fsghsjh', 'fshghs', '2018-06-14 05:13:33', '2018-06-14 05:13:33'),
(33, 'jdvgjh', 'nam', 'nguyenducbkk61@gmail.com', 'jv gsbd', 'jsdgfd', 'tfydfys', '2018-06-14 05:15:42', '2018-06-14 05:15:42'),
(34, 'ja,fsdfj', 'nam', 'nguyenducbkk61@gmail.com', 'gsfadh', 'fg', 'fjwhrgw', '2018-06-14 05:16:31', '2018-06-14 05:16:31'),
(35, 'jfkshgwus', 'nam', 'nguyenducbkk61@gmail.com', 'fjegfewh', 'ỳgdhfg', 'hdfgjsdh', '2018-06-14 05:17:40', '2018-06-14 05:17:40'),
(36, 'kgbjdfk', 'nam', 'nguyenducbkk61@gmail.com', 'igjhlfdj', 'ksgjdr', 'dfhgsh', '2018-06-14 05:19:05', '2018-06-14 05:19:05'),
(37, 'jgje', 'nam', 'nguyenducbkk61@gmail.com', 'jfadgvhs', 'gjsfgwhsj', 'ùygsda', '2018-06-14 05:20:29', '2018-06-14 05:20:29'),
(38, 'kgbek', 'nam', 'nguyenducbkk61@gmail.com', 'ưgterj', 'gjseghejk', 'sgivjdgh', '2018-06-14 05:21:31', '2018-06-14 05:21:31'),
(39, 'fdgfd', 'nam', 'nguyenducbkk61@gmail.com', 'fbffg', 'ffgf', 'fghfhfhf', '2018-06-18 08:24:17', '2018-06-18 08:24:17'),
(40, 'nguyễn văn đức', 'nam', 'nguyenducbkk61@gmail.com', 'phủ doãn', '01668948823', 'nhanh nha', '2018-06-18 09:45:48', '2018-06-18 09:45:48'),
(41, 'đúc', 'nam', 'nguyenducbkk61@gmail.com', 'việt hùng', '01668948823', 'giao nhanh nhá', '2018-06-19 01:37:43', '2018-06-19 01:37:43'),
(42, 'sghadhj', 'nam', 'nguyenducbkk61@gmail.com', 'hgdfhvs', 'agsdvsa', 'adgfda', '2018-09-13 02:23:16', '2018-09-13 02:23:16');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `news`
--

CREATE TABLE `news` (
  `id` int(10) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'tiêu đề',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'nội dung',
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'hình',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `image`, `create_at`, `update_at`) VALUES
(1, 'Mùa trung thu năm nay, Hỷ Lâm Môn muốn gửi đến quý khách hàng sản phẩm mới xuất hiện lần đầu tiên tại Việt nam \"Bánh trung thu Bơ Sữa HongKong\".', 'Những ý tưởng dưới đây sẽ giúp bạn sắp xếp tủ quần áo trong phòng ngủ chật hẹp của mình một cách dễ dàng và hiệu quả nhất. ', 'sample1.jpg', '2017-03-11 06:20:23', '0000-00-00 00:00:00'),
(2, 'Tư vấn cải tạo phòng ngủ nhỏ sao cho thoải mái và thoáng mát', 'Chúng tôi sẽ tư vấn cải tạo và bố trí nội thất để giúp phòng ngủ của chàng trai độc thân thật thoải mái, thoáng mát và sáng sủa nhất. ', 'sample2.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(3, 'Đồ gỗ nội thất và nhu cầu, xu hướng sử dụng của người dùng', 'Đồ gỗ nội thất ngày càng được sử dụng phổ biến nhờ vào hiệu quả mà nó mang lại cho không gian kiến trúc. Xu thế của các gia đình hiện nay là muốn đem thiên nhiên vào nhà ', 'sample3.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(4, 'Hướng dẫn sử dụng bảo quản đồ gỗ, nội thất.', 'Ngày nay, xu hướng chọn vật dụng làm bằng gỗ để trang trí, sử dụng trong văn phòng, gia đình được nhiều người ưa chuộng và quan tâm. Trên thị trường có nhiều sản phẩm mẫu ', 'sample4.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(5, 'Phong cách mới trong sử dụng đồ gỗ nội thất gia đình', 'Đồ gỗ nội thất gia đình ngày càng được sử dụng phổ biến nhờ vào hiệu quả mà nó mang lại cho không gian kiến trúc. Phong cách sử dụng đồ gỗ hiện nay của các gia đình hầu h ', 'sample5.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_type` int(10) UNSIGNED DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `unit_price` float DEFAULT NULL,
  `promotion_price` float DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new` tinyint(4) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `id_type`, `description`, `unit_price`, `promotion_price`, `image`, `unit`, `new`, `created_at`, `updated_at`) VALUES
(1, 'BỘ SP AGELOC® GALVANIC FACE SPA', 1, 'anh bình là admin', 11286000, 11, '1.png', '1', 1, NULL, NULL),
(2, 'Bộ SP ageLOC® Galvanic Body Spa®', 1, '2', 2, 2, '2.png', 'đ', 1, NULL, NULL),
(3, 'Gel mát xa mặt ageLOC Galvanic Facial Gels', 1, '3', 3, 3, '3.png', 'đ', 1, NULL, NULL),
(4, 'Tinh chất dưỡng da chống lão hóa ageLOC® Future ', 1, '4', 4, 4, '4.png', '4', 1, NULL, NULL),
(5, 'Kem phục hồi da ban đêm ageLOC® Transforming ', 1, '5', 1, 1, '5.png', '5', 1, NULL, NULL),
(6, 'Kem chống nắng & dưỡng da ban ngày ageLOC® ', 1, '6', 6, 0, '6.png', '6', 1, NULL, NULL),
(7, 'Sửa rửa mặt & nước hoa hồng dịu nhẹ ageLOC® ', 1, '7', 7, 7, '7.png', '1', 1, NULL, NULL),
(8, '8', 2, '8', 8, 8, '8.png', '8', 1, NULL, NULL),
(10, 'Kem dưỡng thể ageLOC Dermatic Effects®', 1, '3', 6, 7, '10.png', '5', 1, NULL, NULL),
(11, 'Bộ sản phẩm dưỡng da ageLOC® Transformation ', 1, 'y', 6, 6, '11.png', '4', 1, NULL, NULL),
(12, 'ageLOC® Body Shaping Gel', 2, 'f', 122, 11, '12.png', 'd', 1, NULL, NULL),
(13, 'Sữa rửa mặt ageLOC® LumiSpa™ dành cho da ', 1, 'chưa có gì', 1060000, 0, '13.png', '1', 1, NULL, NULL),
(63, 'ageLOC® Body Shaping Gel', 2, '9', 9, 9, '9.png', '9', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `link` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `slide`
--

INSERT INTO `slide` (`id`, `link`, `image`) VALUES
(1, '', 'banner11.jpg'),
(2, '', 'banner22.jpg'),
(3, '', 'banner33.jpg'),
(4, '', 'banner44.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `type_products`
--

CREATE TABLE `type_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `type_products`
--

INSERT INTO `type_products` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'làm đẹp', 'làm đẹp', '1.png', NULL, NULL),
(2, 'sức khỏe', 'sức khỏe', '20131108144733.jpg', '2016-10-12 02:16:15', '2016-10-13 01:38:35');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `phone`, `address`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, 'Hương Hương', 'huonghuong08.php@gmail.com', '$2y$10$rGY4KT6ZSMmLnxIbmTXrsu2xdgRxm8x0UTwCyYCAzrJ320kYheSRq', '23456789', 'Hoàng Diệu 2', NULL, '2017-03-23 07:17:33', '2017-03-23 07:17:33');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bills_ibfk_1` (`id_customer`);

--
-- Chỉ mục cho bảng `bill_detail`
--
ALTER TABLE `bill_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bill_detail_ibfk_2` (`id_product`),
  ADD KEY `id_bill` (`id_bill`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_id_type_foreign` (`id_type`);

--
-- Chỉ mục cho bảng `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `type_products`
--
ALTER TABLE `type_products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT cho bảng `bill_detail`
--
ALTER TABLE `bill_detail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT cho bảng `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `type_products`
--
ALTER TABLE `type_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_id_type_foreign` FOREIGN KEY (`id_type`) REFERENCES `type_products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
